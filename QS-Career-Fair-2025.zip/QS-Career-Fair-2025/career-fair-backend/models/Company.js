const mongoose = require('mongoose');

const companySchema = new mongoose.Schema({
    name: { type: String, required: true },
    description: { type: String },
    availableSlots: { type: Number, required: true },
    totalSlots: { type: Number, required: true },
});

module.exports = mongoose.model('Company', companySchema);