const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema({
    index: { type: String, required: true, unique: true },
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    remainingRequests: { type: Number, default: 5 },
    registrationDate: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Student', studentSchema);