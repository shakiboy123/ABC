const mongoose = require('mongoose');

const interviewRequestSchema = new mongoose.Schema({
    companyId: { type: mongoose.Schema.Types.ObjectId, ref: 'Company', required: true },
    studentIndex: { type: String, required: true },
    studentName: { type: String, required: true },
    requestDate: { type: Date, default: Date.now },
});

module.exports = mongoose.model('InterviewRequest', interviewRequestSchema);