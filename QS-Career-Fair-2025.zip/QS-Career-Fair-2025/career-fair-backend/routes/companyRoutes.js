const express = require('express');
const Company = require('../models/Company');
const router = express.Router();

// Add/Update Company
router.post('/', async (req, res) => {
    const { name, description, availableSlots, totalSlots } = req.body;

    try {
        const company = new Company({ name, description, availableSlots, totalSlots });
        await company.save();
        res.status(201).json({ message: 'Company added successfully!', company });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

// Get All Companies
router.get('/', async (req, res) => {
    try {
        const companies = await Company.find();
        res.json(companies);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

module.exports = router;