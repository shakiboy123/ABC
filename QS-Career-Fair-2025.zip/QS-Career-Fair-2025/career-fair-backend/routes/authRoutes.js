const express = require('express');
const Student = require('../models/Student');
const router = express.Router();

// Student Registration
router.post('/register', async (req, res) => {
    const { index, name, email, password } = req.body;

    try {
        const student = new Student({ index, name, email, password });
        await student.save();
        res.status(201).json({ message: 'Registration successful!' });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

// Student Login
router.post('/login', async (req, res) => {
    const { index, password } = req.body;

    try {
        const student = await Student.findOne({ index, password });
        if (!student) throw new Error('Invalid index or password');
        res.json({ message: 'Login successful!', student });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

module.exports = router;