const express = require('express');
const InterviewRequest = require('../models/InterviewRequest');
const Company = require('../models/Company');
const Student = require('../models/Student');
const router = express.Router();

// Request Interview
router.post('/', async (req, res) => {
    const { companyId, studentIndex } = req.body;

    try {
        const company = await Company.findById(companyId);
        if (!company || company.availableSlots <= 0) throw new Error('No slots available');

        const student = await Student.findOne({ index: studentIndex });
        if (!student || student.remainingRequests <= 0) throw new Error('No remaining requests');

        const request = new InterviewRequest({ companyId, studentIndex, studentName: student.name });
        await request.save();

        company.availableSlots--;
        student.remainingRequests--;
        await company.save();
        await student.save();

        res.status(201).json({ message: 'Interview request submitted!', request });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

module.exports = router;